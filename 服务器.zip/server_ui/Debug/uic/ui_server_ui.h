/********************************************************************************
** Form generated from reading UI file 'server_ui.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERVER_UI_H
#define UI_SERVER_UI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_server_uiClass
{
public:
    QWidget *centralWidget;
    QLabel *timeLabel;
    QPushButton *pB_floor2;
    QPushButton *pB_floor3;
    QPushButton *pB_floor4;
    QLabel *lable_price;
    QLabel *label_mode;
    QLabel *label_power;
    QTextEdit *textEdit_room1;
    QTextEdit *textEdit_room4;
    QTextEdit *textEdit_room7;
    QTextEdit *textEdit_room10;
    QTextEdit *textEdit_room2;
    QTextEdit *textEdit_room5;
    QTextEdit *textEdit_room8;
    QTextEdit *textEdit_room3;
    QTextEdit *textEdit_room6;
    QTextEdit *textEdit_room9;
    QPushButton *pB_floor1;
    QFrame *frame;
    QPushButton *pB_power;
    QComboBox *cB_mode;
    QDoubleSpinBox *doubleSpinBox;

    void setupUi(QMainWindow *server_uiClass)
    {
        if (server_uiClass->objectName().isEmpty())
            server_uiClass->setObjectName(QString::fromUtf8("server_uiClass"));
        server_uiClass->resize(1170, 666);
        server_uiClass->setMinimumSize(QSize(0, 0));
        server_uiClass->setStyleSheet(QString::fromUtf8(""));
        centralWidget = new QWidget(server_uiClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        timeLabel = new QLabel(centralWidget);
        timeLabel->setObjectName(QString::fromUtf8("timeLabel"));
        timeLabel->setGeometry(QRect(10, 10, 511, 61));
        timeLabel->setLayoutDirection(Qt::LeftToRight);
        timeLabel->setStyleSheet(QString::fromUtf8("font: 14pt \"Consolas\";"));
        pB_floor2 = new QPushButton(centralWidget);
        pB_floor2->setObjectName(QString::fromUtf8("pB_floor2"));
        pB_floor2->setGeometry(QRect(640, 70, 121, 51));
        pB_floor2->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        pB_floor2->setCheckable(true);
        pB_floor2->setAutoExclusive(true);
        pB_floor3 = new QPushButton(centralWidget);
        pB_floor3->setObjectName(QString::fromUtf8("pB_floor3"));
        pB_floor3->setGeometry(QRect(800, 70, 121, 51));
        pB_floor3->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
""));
        pB_floor3->setCheckable(true);
        pB_floor3->setAutoExclusive(true);
        pB_floor4 = new QPushButton(centralWidget);
        pB_floor4->setObjectName(QString::fromUtf8("pB_floor4"));
        pB_floor4->setGeometry(QRect(960, 70, 121, 51));
        pB_floor4->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
""));
        pB_floor4->setCheckable(true);
        pB_floor4->setAutoExclusive(true);
        lable_price = new QLabel(centralWidget);
        lable_price->setObjectName(QString::fromUtf8("lable_price"));
        lable_price->setGeometry(QRect(20, 300, 111, 61));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(14);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        lable_price->setFont(font);
        lable_price->setLayoutDirection(Qt::LeftToRight);
        lable_price->setAutoFillBackground(false);
        lable_price->setStyleSheet(QString::fromUtf8("font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"font: 14pt \"Arial\";\n"
""));
        label_mode = new QLabel(centralWidget);
        label_mode->setObjectName(QString::fromUtf8("label_mode"));
        label_mode->setGeometry(QRect(20, 390, 111, 61));
        label_mode->setFont(font);
        label_mode->setStyleSheet(QString::fromUtf8("font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"font: 14pt \"Arial\";\n"
"\n"
""));
        label_power = new QLabel(centralWidget);
        label_power->setObjectName(QString::fromUtf8("label_power"));
        label_power->setGeometry(QRect(20, 480, 111, 61));
        label_power->setStyleSheet(QString::fromUtf8("font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"\n"
"font: 14pt \"Arial\";"));
        textEdit_room1 = new QTextEdit(centralWidget);
        textEdit_room1->setObjectName(QString::fromUtf8("textEdit_room1"));
        textEdit_room1->setGeometry(QRect(350, 130, 151, 231));
        textEdit_room1->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        textEdit_room1->setTextInteractionFlags(Qt::NoTextInteraction);
        textEdit_room4 = new QTextEdit(centralWidget);
        textEdit_room4->setObjectName(QString::fromUtf8("textEdit_room4"));
        textEdit_room4->setGeometry(QRect(830, 130, 151, 231));
        textEdit_room4->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        textEdit_room4->setTextInteractionFlags(Qt::NoTextInteraction);
        textEdit_room7 = new QTextEdit(centralWidget);
        textEdit_room7->setObjectName(QString::fromUtf8("textEdit_room7"));
        textEdit_room7->setGeometry(QRect(510, 370, 151, 231));
        textEdit_room7->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        textEdit_room7->setTextInteractionFlags(Qt::NoTextInteraction);
        textEdit_room10 = new QTextEdit(centralWidget);
        textEdit_room10->setObjectName(QString::fromUtf8("textEdit_room10"));
        textEdit_room10->setGeometry(QRect(990, 370, 151, 231));
        textEdit_room10->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        textEdit_room10->setTextInteractionFlags(Qt::NoTextInteraction);
        textEdit_room2 = new QTextEdit(centralWidget);
        textEdit_room2->setObjectName(QString::fromUtf8("textEdit_room2"));
        textEdit_room2->setGeometry(QRect(510, 130, 151, 231));
        textEdit_room2->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        textEdit_room2->setTextInteractionFlags(Qt::NoTextInteraction);
        textEdit_room5 = new QTextEdit(centralWidget);
        textEdit_room5->setObjectName(QString::fromUtf8("textEdit_room5"));
        textEdit_room5->setGeometry(QRect(990, 130, 151, 231));
        textEdit_room5->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        textEdit_room5->setTextInteractionFlags(Qt::NoTextInteraction);
        textEdit_room8 = new QTextEdit(centralWidget);
        textEdit_room8->setObjectName(QString::fromUtf8("textEdit_room8"));
        textEdit_room8->setGeometry(QRect(670, 370, 151, 231));
        textEdit_room8->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        textEdit_room8->setTextInteractionFlags(Qt::NoTextInteraction);
        textEdit_room3 = new QTextEdit(centralWidget);
        textEdit_room3->setObjectName(QString::fromUtf8("textEdit_room3"));
        textEdit_room3->setGeometry(QRect(670, 130, 151, 231));
        textEdit_room3->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        textEdit_room3->setTextInteractionFlags(Qt::NoTextInteraction);
        textEdit_room6 = new QTextEdit(centralWidget);
        textEdit_room6->setObjectName(QString::fromUtf8("textEdit_room6"));
        textEdit_room6->setGeometry(QRect(350, 370, 151, 231));
        textEdit_room6->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        textEdit_room6->setTextInteractionFlags(Qt::NoTextInteraction);
        textEdit_room9 = new QTextEdit(centralWidget);
        textEdit_room9->setObjectName(QString::fromUtf8("textEdit_room9"));
        textEdit_room9->setGeometry(QRect(830, 370, 151, 231));
        textEdit_room9->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        textEdit_room9->setTextInteractionFlags(Qt::NoTextInteraction);
        pB_floor1 = new QPushButton(centralWidget);
        pB_floor1->setObjectName(QString::fromUtf8("pB_floor1"));
        pB_floor1->setGeometry(QRect(480, 70, 121, 51));
        pB_floor1->setStyleSheet(QString::fromUtf8("\n"
"font: 9pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
""));
        pB_floor1->setCheckable(true);
        pB_floor1->setChecked(false);
        pB_floor1->setAutoExclusive(true);
        frame = new QFrame(centralWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(460, 60, 611, 61));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        pB_power = new QPushButton(centralWidget);
        pB_power->setObjectName(QString::fromUtf8("pB_power"));
        pB_power->setGeometry(QRect(160, 480, 121, 71));
        pB_power->setStyleSheet(QString::fromUtf8("border-image: url(:/server_ui/close1.png);"));
        cB_mode = new QComboBox(centralWidget);
        cB_mode->addItem(QString());
        cB_mode->addItem(QString());
        cB_mode->setObjectName(QString::fromUtf8("cB_mode"));
        cB_mode->setGeometry(QRect(160, 390, 161, 71));
        cB_mode->setContextMenuPolicy(Qt::DefaultContextMenu);
        cB_mode->setLayoutDirection(Qt::LeftToRight);
        cB_mode->setAutoFillBackground(false);
        cB_mode->setStyleSheet(QString::fromUtf8("font: 14pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";"));
        cB_mode->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLength);
        doubleSpinBox = new QDoubleSpinBox(centralWidget);
        doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBox"));
        doubleSpinBox->setGeometry(QRect(160, 300, 161, 71));
        doubleSpinBox->setStyleSheet(QString::fromUtf8("font: 20pt \"Consolas\";\n"
""));
        doubleSpinBox->setAlignment(Qt::AlignCenter);
        doubleSpinBox->setAccelerated(false);
        doubleSpinBox->setKeyboardTracking(true);
        doubleSpinBox->setProperty("showGroupSeparator", QVariant(false));
        server_uiClass->setCentralWidget(centralWidget);
        frame->raise();
        timeLabel->raise();
        pB_floor2->raise();
        pB_floor3->raise();
        pB_floor4->raise();
        lable_price->raise();
        label_mode->raise();
        label_power->raise();
        textEdit_room1->raise();
        textEdit_room4->raise();
        textEdit_room7->raise();
        textEdit_room10->raise();
        textEdit_room2->raise();
        textEdit_room5->raise();
        textEdit_room8->raise();
        textEdit_room3->raise();
        textEdit_room6->raise();
        textEdit_room9->raise();
        pB_floor1->raise();
        pB_power->raise();
        cB_mode->raise();
        doubleSpinBox->raise();

        retranslateUi(server_uiClass);
        QObject::connect(pB_floor2, SIGNAL(clicked()), server_uiClass, SLOT(click_pB_floor2()));
        QObject::connect(pB_floor3, SIGNAL(clicked()), server_uiClass, SLOT(click_pB_floor3()));
        QObject::connect(pB_floor4, SIGNAL(clicked()), server_uiClass, SLOT(click_pB_floor4()));
        QObject::connect(pB_floor1, SIGNAL(clicked()), server_uiClass, SLOT(click_pB_floor1()));
        QObject::connect(pB_power, SIGNAL(clicked()), server_uiClass, SLOT(set_power_on()));
        QObject::connect(cB_mode, SIGNAL(currentIndexChanged(int)), server_uiClass, SLOT(set_mode()));
        QObject::connect(doubleSpinBox, SIGNAL(valueChanged(double)), server_uiClass, SLOT(set_price()));

        QMetaObject::connectSlotsByName(server_uiClass);
    } // setupUi

    void retranslateUi(QMainWindow *server_uiClass)
    {
        server_uiClass->setWindowTitle(QApplication::translate("server_uiClass", "server_ui", nullptr));
        timeLabel->setText(QApplication::translate("server_uiClass", "TextLabel", nullptr));
        pB_floor2->setText(QApplication::translate("server_uiClass", "\344\272\214\346\245\274", nullptr));
        pB_floor3->setText(QApplication::translate("server_uiClass", "\344\270\211\346\245\274", nullptr));
        pB_floor4->setText(QApplication::translate("server_uiClass", "\345\233\233\346\245\274", nullptr));
        lable_price->setText(QApplication::translate("server_uiClass", "    \350\264\271\347\216\207", nullptr));
        label_mode->setText(QApplication::translate("server_uiClass", "    \346\250\241\345\274\217", nullptr));
        label_power->setText(QApplication::translate("server_uiClass", "    \347\224\265\346\272\220", nullptr));
        pB_floor1->setText(QApplication::translate("server_uiClass", "\344\270\200\346\245\274", nullptr));
        pB_power->setText(QString());
        cB_mode->setItemText(0, QApplication::translate("server_uiClass", "\345\210\266\345\206\267", nullptr));
        cB_mode->setItemText(1, QApplication::translate("server_uiClass", "\350\276\205\347\203\255", nullptr));

    } // retranslateUi

};

namespace Ui {
    class server_uiClass: public Ui_server_uiClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERVER_UI_H
