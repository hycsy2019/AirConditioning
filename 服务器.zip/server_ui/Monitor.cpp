#include "Monitor.h"

FILE* f = fopen("C:\\Users\\dq2000\\Desktop\\server_ui\\Debug\\err.txt", "w");

//FILE* f = fopen("err.txt", "w");

Monitor::Monitor(RD *DataBase) {

	this->DataBase = DataBase;
	//this->queue = queue;

	endPoint.set_error_channels(websocketpp::log::elevel::all);
	endPoint.set_access_channels(websocketpp::log::alevel::all ^ websocketpp::log::alevel::frame_payload);
	endPoint.init_asio();

	endPoint.set_open_handler(bind(&Monitor::on_handler, this, placeholders::_1));
	endPoint.set_message_handler(bind(&Monitor::on_message, this, placeholders::_1, placeholders::_2));
	endPoint.set_close_handler(bind(&Monitor::on_close, this, ::_1));
}

void Monitor::on_handler(websocketpp::connection_hdl hdl) {
	server::connection_ptr con = endPoint.get_con_from_hdl(hdl);      // �������Ӿ��������Ӷ���
	string path = con->get_resource();								  // ���URL·��
	path.erase(0,1);
//	cout << "\npath = " << path << endl;
//	lock_guard<std::mutex> lock(mMutex);
	//if (!hdlToRoom.count(path)) {									  //����ǵ�һ�ν�������
	//	mConnections.insert(hdl);									  //���Ӿ���洢��mConnection��
	//	hdlToRoom[path] = -1;										  //����hdl�뷿���Ӧ��ϵ
	//}
	roomTohdl[stoi(path)] = hdl;

	endPoint.get_alog().write(websocketpp::log::alevel::app, "Connected to path " + path);
}

void Monitor::on_close(websocketpp::connection_hdl hdl) {
//	lock_guard<std::mutex> lock(mMutex);
//	mConnections.erase(hdl);
//	hdlToRoom.erase(endPoint.get_con_from_hdl(hdl)->get_resource());
	string path = endPoint.get_con_from_hdl(hdl)->get_resource();
	roomTohdl.erase(stoi(path.erase(0, 1)));
}


void Monitor::on_message(websocketpp::connection_hdl hdl, server::message_ptr msg) {
//	cout << msg << endl;
	string path = endPoint.get_con_from_hdl(hdl)->get_resource();

	Json::Reader* readerinfo = new Json::Reader(Json::Features::strictMode());
	Json::Value root;
	readerinfo->parse(msg->get_payload(), root);
	//�����յ���json��Ϣ
	
	//if (hdlToRoom[path] < 0) {//hdl��room��Ӧ��ϵδ����ʱ������Ӧ��ϵ
	//	hdlToRoom[path] = root["room_id"].asInt();
	//}
	//cout << root.toStyledString() << endl;
	fprintf_s(f, "(%s)\n", root.toStyledString().c_str());
	//ͨ��event�ֱ�����
	string event = root["event"].asString();

	lock_guard<std::mutex> lock(mMutex);
	if (event == "on")event_on(root, hdl);
	else if (event == "set")event_set(root, hdl);
	else if (event == "tem")event_tem(root, hdl);
	else if (event == "off")event_off(root,hdl);

}

void Monitor::event_on(Json::Value& root, websocketpp::connection_hdl hdl) {
	//�յ�������Ϣ���½�������Ϣ�࣬���������Ϣ�������ݿ�
	timeb t;
	ftime(&t);
	Json::Value myRoot = root;
	long cur_time = t.time * 1000 + t.millitm;

	if (true) {//��ѯ���÷�������ס

		room.clear();

		queue.dispatch(root["room_id"].asInt(), root["data"]["wind"].asInt(), room);

		if (room.size() == 0) {
			root["data"]["wind"] = 0;
			root["data"]["tem_low_limit"] = TEM_LOW_LIMIT;
			root["data"]["tem_high_limit"] = TEM_HIGH_LIMIT;
			root["data"]["default_tar_tem"] = DEFAULT_TAR_TEM;

			send_message(hdl, root);

			myRoot["data"]["state"] = 3;
			DataBase->Update(myRoot);
			myRoot["data"]["fee"] = 0;
			myRoot["wait_time"] = 0;
			myRoot["event_type"] = 0;//����
			DataBase->InsertToEventTable(myRoot);

			myRoot["timestamp"] = to_string(cur_time);
			myRoot["data"]["wind"] = 0;
			myRoot["event_type"] = 4;//������ͣ
			DataBase->InsertToEventTable(myRoot);
		}
		else if (room.size() == 1) {
			root["data"]["tem_low_limit"] = TEM_LOW_LIMIT;
			root["data"]["tem_high_limit"] = TEM_HIGH_LIMIT;
			root["data"]["default_tar_tem"] = DEFAULT_TAR_TEM;

			send_message(hdl, root);

			myRoot["data"]["state"] = 1;
			DataBase->Update(myRoot);
			myRoot["data"]["cur_fee"] = 0;
			myRoot["wait_time"] = 0;
			myRoot["event_type"] = 0;
			DataBase->InsertToEventTable(myRoot);
		}
		else {
			root["event"] = "set";
			root["data"]["wind"] = 0;
			root["room_id"] = room[0].room_id;
			send_message(roomTohdl[room[0].room_id], root);

			myRoot["room_id"] = room[0].room_id;
			myRoot["data"]["state"] = 3;
			DataBase->Update(myRoot);

			myRoot["timestamp"] = to_string(cur_time);
			myRoot["data"]["wind"] = 0;
			myRoot["event_type"] = 4;//������ͣ
			DataBase->InsertToEventTable(myRoot);

			//����Ϊ������ͣ�Ĳ���

			root["event"] = "on";
			root["data"]["wind"] = room[1].wind;
			root["room_id"] = room[1].room_id;
			root["data"]["tem_low_limit"] = TEM_LOW_LIMIT;
			root["data"]["tem_high_limit"] = TEM_HIGH_LIMIT;
			root["data"]["default_tar_tem"] = DEFAULT_TAR_TEM;

			send_message(hdl, root);

			myRoot["room_id"] = room[1].room_id;
			myRoot["data"]["state"] = 1;
			DataBase->Update(myRoot);
			myRoot["data"]["cur_fee"] = 0;
			myRoot["wait_time"] = 0;
			myRoot["data"]["wind"] = room[1].wind;
			myRoot["event_type"] = 0;
			DataBase->InsertToEventTable(myRoot);
		}


		//for (int i = 0; i < room.size(); i++) {
		//	if (room[i].waiting_time > 0) {
		//		myRoot["data"]["state"] = 1;
		//		DataBase->Update(myRoot);
		//		myRoot["data"]["cur_fee"] = 0;
		//		myRoot["wait_time"] = 0;
		//		myRoot["event_type"] = 0;
		//		DataBase->InsertToEventTable(myRoot);
		//	}
		//	else {
		//		myRoot["data"]["state"] = 3;
		//		DataBase->Update(myRoot);
		//		myRoot["data"]["fee"] = 0;
		//		myRoot["wait_time"] = 0;
		//		myRoot["event_type"] = 0;//����
		//		DataBase->InsertToEventTable(myRoot);

		//		myRoot["timestamp"] = to_string(cur_time);
		//		myRoot["data"]["wind"] = 0;
		//		myRoot["event_type"] = 4;//������ͣ
		//		DataBase->InsertToEventTable(myRoot);
		//	}
	}





	//	int flag = queue.dispatch(root["room_id"].asInt(), root["data"]["wind"].asInt());

	//	if (queue.dispatch(root["room_id"].asInt(), root["data"]["wind"].asInt()) < 0){
	//		root["data"]["state"] = 1;
	//		DataBase->Update(root);
	//		root["data"]["cur_fee"] = 0;
	//		root["wait_time"] = 0;
	//		root["event_type"] = 0;//����
	//		DataBase->InsertToEventTable(root);
	//	}
	//	else {
	//		root["data"]["state"] = 3;
	//		DataBase->Update(root);
	//		root["data"]["fee"] = 0;
	//		root["wait_time"] = 0;
	//		root["event_type"] = 0;//����
	//		DataBase->InsertToEventTable(root);

	//		root["timestamp"] = to_string(cur_time);
	//		root["data"]["wind"] = 0;
	//		root["event_type"] = 4;//������ͣ
	//		DataBase->InsertToEventTable(root);
	//	}

	//	root.removeMember("event_type");
	//	root.removeMember("wait_time");
	//	root["data"].removeMember("state");

	//	send_message(hdl, root);
	//}
}
void Monitor::event_off(Json::Value& root, websocketpp::connection_hdl hdl) {
	//(room_id,running_time,cur_temp,tar_temp,wind,total_fee,fee,mode,room_type,state)
	MYSQL_ROW row = DataBase->select(to_string(root["room_id"].asInt()));//ȡ���������������
	root["data"]["tot_fee"] = atof(row[5]);
	root["data"]["cur_fee"] = atof(row[6]);

	send_message(hdl, root);

	root["event_type"] = 1;//�ػ�
	DataBase->InsertToEventTable(root);
	DataBase->Update(root);	//�������ݿ�ػ�ʱ��

	room.clear();
	queue.dispatch(root["room_id"].asInt(), 0, room);
	if (room.size() == 2) {
		MYSQL_ROW row = DataBase->select(to_string(room[1].room_id));//ȡ���������������
		root["event"] = "set";
		root["data"]["wind"] = atoi(row[4]);
		root["room_id"] = room[1].room_id;
		send_message(roomTohdl[room[1].room_id], root);
		root["data"]["cur_tem"] = atof(row[2]);
		root["data"]["tar_tem"] = atof(row[3]);
		root["data"]["state"] = 1;
		DataBase->Update(root);//���·�������״̬

		root["event_type"] = 5;//���ȿ���
		DataBase->InsertToEventTable(root);
	}
}

void Monitor::event_tem(Json::Value& root,websocketpp::connection_hdl hdl) {
	//(room_id,running_time,cur_temp,tar_temp,wind,total_fee,fee,mode,room_type,state)
	MYSQL_ROW row = DataBase->select(to_string(root["room_id"].asInt()));//ȡ���������������

	root["data"]["mode"] = MODE;
	root["data"]["tot_fee"] = atof(row[5]);
	root["data"]["cur_fee"] = atof(row[6]);
	root["data"]["state"] = atoi(row[9]);

	if (atoi(row[9]) == 1 && atoi(row[4]) > 0) {
		root["data"]["cur_fee"] = root["data"]["cur_fee"].asDouble() + (fabs(root["data"]["cur_tem"].asDouble() - atof(row[2]))) * PRICE;
		root["data"]["tot_fee"] = root["data"]["tot_fee"].asDouble() + (fabs(root["data"]["cur_tem"].asDouble() - atof(row[2]))) * PRICE;
	}
	//else if(atoi(row[9]) == 2 && fabs(root["data"]["cur_tem"].asDouble() - atof(row[3]) > 0.99)){
	//	root["data"]["state"] = 1;
	//	root["event_type"] = 7;//�¶�ƫ�뿪��
	//	root["data"]["wind"] = atoi(row[4]);
	//}
	send_message(hdl, root);

	//if (fabs(root["data"]["cur_tem"].asDouble() - atof(row[3]) < 1e-1)) {
	//	root["data"]["state"] = 2;
	//	root["event_type"] = 6;//�¶ȵ�����ͣ
	//	root["data"]["wind"] = atoi(row[4]);
	//}
	DataBase->Update(root);
	DataBase->InsertToEventTable(root);
}

void Monitor::event_set(Json::Value& root,websocketpp::connection_hdl hdl) {

	//(room_id,running_time,cur_temp,tar_temp,wind,total_fee,fee,mode,room_type,state)
	MYSQL_ROW row = DataBase->select(to_string(root["room_id"].asInt()));//ȡ���������������

	//��������¼�
	if (root["data"]["wind"].asInt() != atoi(row[4])) {
		root["data"]["cur_fee"] = atof(row[6]);
		if (atoi(row[9]) == 1)
			root["data"]["cur_fee"] = root["data"]["cur_fee"].asDouble() + (fabs(root["data"]["cur_tem"].asDouble() - atof(row[2]))) * PRICE;
		root["event_type"] = 2; //��������
	}
	else {
		root["data"]["cur_tem"] = atof(row[2]);
		root["event_type"] = 3; //�ı��¶�
		root["data"]["cur_fee"] = 0;
	}

	root["data"]["state"] = atoi(row[9]);

	DataBase->Update(root);
	DataBase->InsertToEventTable(root);
	
	//�ı����ʱҪ���е���
	if (root["event_type"].asInt() == 2) {
		room.clear();
		queue.dispatch(root["room_id"].asInt(), root["data"]["wind"].asInt(),room);

		if (room.size() == 0) {
			root["data"]["wind"] = 0;
			send_message(hdl, root);
		}
		else if (room.size() == 1) {
			if (room[0].waiting_time > 0) {
				send_message(hdl, root);
				root["data"]["state"] = 1;
				DataBase->Update(root);//���·�������״̬

				root["event_type"] = 5;//���ȿ���
				DataBase->InsertToEventTable(root);
			}
			else {
				send_message(hdl, root);
				root["data"]["state"] = 3;
				DataBase->Update(root);//���·�������״̬

				root["event_type"] = 6;//�¶ȵ�����ͣ
				DataBase->InsertToEventTable(root);
			}
		}
		else {
			root["room_id"] = room[1].room_id;
			send_message(roomTohdl[room[1].room_id], root);
			root["data"]["state"] = 1;
			DataBase->Update(root);//���·�������״̬

			root["event_type"] = 5;//���ȿ���
			DataBase->InsertToEventTable(root);



			root["room_id"] = room[0].room_id;
			root["event_type"] = 4;//������ͣ
			row = DataBase->select(to_string(room[0].room_id));
			root["data"]["cur_fee"] = atof(row[6]);
			root["data"]["wind"] = 0;
			root["data"]["state"] = 3;
			DataBase->InsertToEventTable(root);
			DataBase->Update(root);//���·�������״̬

			send_message(roomTohdl[room[0].room_id], root);
		}
	}





//	if (root["event_type"].asInt() == 2) {
//		int room_id = queue.dispatch(root["room_id"].asInt(), root["data"]["wind"].asInt());
//		if (room_id != root["room_id"].asInt()) {
//			//�����俪ʼ����
//			send_message(hdl, root);
//			root["data"]["state"] = 1;
//			DataBase->Update(root);//���·�������״̬
//
//			root["event_type"] = 5;//���ȿ���
//			DataBase->InsertToEventTable(root); 
//
//			if (room_id > 0) {//�������䱻������ͣ
////				root["data"].clear();
//				root["room_id"] = room_id;
//				root["event_type"] = 4;//������ͣ
//				row = DataBase->select(to_string(room_id));
//				root["data"]["cur_fee"] = atof(row[6]);
//				root["data"]["wind"] = 0;
//				root["data"]["state"] = 3;
//				DataBase->InsertToEventTable(root);
//				DataBase->Update(root);//���·�������״̬
//
//				send_message(roomTohdl[room_id], root);
//			}
//		}
//		else {//�����������ͣ
//			root["data"]["wind"] = 0;
//
//			send_message(hdl, root);
//		}
//	}
//	else {
//		//root["event_type"].clear();
//		//root["data"]["cur_fee"].clear();
//		//root["data"]["cur_tmep"].clear();
//
//		root.removeMember("event_type");
//		root["data"].removeMember("cur_fee");
//		root["data"].removeMember("cur_tem");
//
//		send_message(hdl, root);
//	}
}

void Monitor::re_message() {
	//���ͷ��ر���
	Json::Value Root;
	timeb t;
	while (true) {
		Sleep(3000);

		lock_guard<std::mutex> lock(mMutex);

		room.clear();

		queue.scheduling(room);
		for (int i = 0; i < room.size(); i++) {

			ftime(&t);

			Root["room_id"] = room[i].room_id;
			Root["event"] = "sch";
			Root["status"] = 0;
			Root["timestamp"] = to_string(t.time * 1000 + t.millitm);
			Root["data"]["wind"] = room[i].wind;
			Root["data"]["waiting_time"] = room[i].waiting_time;
			if (room[i].waiting_time == 0) {
				Root["data"]["state"] = 3;
				DataBase->Update(Root);
				Root["data"]["wind"] = 0;
			}
			else { 
				Root["data"]["state"] = 1;
				DataBase->Update(Root);
			}
			Root["event"] = "set";

			send_message(roomTohdl[room[i].room_id], Root);
		}
	}
}

void Monitor::send_message(websocketpp::connection_hdl hdl,Json::Value& root) {

	root["status"] = 0;
	string reStr = root.toStyledString();
	endPoint.send(hdl, reStr, websocketpp::frame::opcode::text);

}

void Monitor::run() {
	endPoint.set_reuse_addr(true);
	endPoint.listen(80);
	endPoint.start_accept();
//	DataBase->start();
	endPoint.run();
}

