#pragma once

#include <websocketpp/config/asio_no_tls.hpp>
#include <websocketpp/server.hpp>
#include <iostream>
#include "RD.h"
#include "Scheduler.h"
#include <functional>
#include <windows.h>
#include <thread>
#include <mutex>
#include <set>
#include <map>
#include <cmath>
#include <sys/timeb.h>


using namespace std;

typedef websocketpp::server<websocketpp::config::asio> server;
using websocketpp::connection_hdl;
using websocketpp::lib::placeholders::_1;
using websocketpp::lib::placeholders::_2;
//using websocketpp::lib::bind;

extern int PRICE;
extern int MODE;

extern int TEM_LOW_LIMIT;
extern int TEM_HIGH_LIMIT;
extern int DEFAULT_TAR_TEM;

extern FILE* f;

class Monitor{
public:
	Monitor(RD *DataBase);
	void run();
	void on_handler(websocketpp::connection_hdl hdl);
	void on_message(websocketpp::connection_hdl hdl, server::message_ptr msg);
	void on_close(websocketpp::connection_hdl hdl);
	void send_message(websocketpp::connection_hdl hdl,Json::Value& root);



	void re_message();


	void event_on(Json::Value& root, websocketpp::connection_hdl hdl);//��event��Ӧ�Ĵ�������
	void event_off(Json::Value& root, websocketpp::connection_hdl hdl);
	void event_set(Json::Value& root, websocketpp::connection_hdl hdl);
	void event_tem(Json::Value& root, websocketpp::connection_hdl hdl);

private:
	typedef set<connection_hdl, owner_less<connection_hdl>> con_list;

	server endPoint;
	con_list mConnections;
	map <string, int> hdlToRoom;
	map <int, connection_hdl> roomTohdl;
	mutex mMutex;
	vector<Room> room;
	Scheduler queue;

	RD *DataBase;
};
