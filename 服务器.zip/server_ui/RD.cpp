#include "RD.h"

int PRICE = 1;
int MODE = 0;
string STATE[] = { u8"δ��ס",u8"�ػ�",u8"����",u8"����",u8"����" };

int TEM_LOW_LIMIT = 17;
int TEM_HIGH_LIMIT = 26;
int DEFAULT_TAR_TEM = 25;

//FILE* f = fopen("C:\\Users\\dq2000\\Desktop\\server_ui\\Debug\\err.txt", "w");


bool RD::connect() {

	mysql_init(&mysql);  //����mysql�����ݿ�  
	const char host[] = "localhost";
	const char user[] = "root";
	const char psw[] = "newpassword";
	const char table[] = "HotelData";
	const int port = 3306;
	if (!(mysql_real_connect(&mysql, host, user, psw, table, port, NULL, 0)))
		//�м�ֱ����������û��������룬���ݿ������˿ںţ�����дĬ��0����3306�ȣ���������д�ɲ����ٴ���ȥ  
	{
		printf("Error connecting to database:%s\n", mysql_error(&mysql));
		return false;
	}
	else
	{
		printf("Connected...\n");
		return true;
	}
}

void RD::freeConnect() {
	mysql_close(&mysql);	 //�ر�һ�����������ӡ�
}

void RD::create() {
	string str;
	str = "create table CheckInTable(";
	str += "customer_id int not null primary key,";
	str += "name text not null,";
	str += "checkIn_time bigint not null,";
	str += "checkOut_time bigint,";
	str += "room_id int not null";
	str += ");";
	if (mysql_query(&mysql, str.c_str())){        //ִ��SQL���
		printf("create checkintable query failed (%s)\n", mysql_error(&mysql));
	}
	else{
		printf("create checkintable query success\n");
	}

	str = "create table eventTable(";
	str += "room_id int not null,";
	str += "event_time bigint not null,";
	str += "event_type int,";
	str += "fee real,";
	str += "wind int,";
	str += "wait_time int,";
	str += "primary key(room_id,event_time)";
	str += ");";
	if (mysql_query(&mysql, str.c_str())) {        
		printf("create turnontable query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		printf("create turnontable query success\n");
	}

	str = "create table runTable(";
	str += "room_id int not null primary key,";
	str += "running_time bigint not null,";
	str += "cur_temp real not null,";
	str += "tar_temp real not null,";
	str += "wind int not null,";
	str += "tot_fee real not null,";
	str += "fee real not null,";
	str += "mode int not null,";
	str += "room_type int not null,";
	str += "state int not null";
	str += ");";
	if (mysql_query(&mysql, str.c_str())) {        
		printf("create runtable query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		printf("create runtable query success\n");
	}

	str = "create table userTable(";
	str += "user_id int not null primary key,";
	str += "user_name text not null,";
	str += "password text not null,";
	str += "permission int not null";
	str += ");";
	if (mysql_query(&mysql, str.c_str())) {        //ִ��SQL���
		printf("create usertable query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		printf("create usertable query success\n");
	}

	for (int i = 1; i <= 4; i++) {
		for (int j = 1; j <= 10; j++) {
			InsertToRunTable(to_string(i * 100 + j), "0", "0", "0", "0", "0", "0", to_string(MODE),"0" ,"-1");
		}
	}

	str = "insert into userTable values (1,'root','123456',1);";
	if (mysql_query(&mysql, str.c_str())) {        //ִ��SQL���
		printf("insert usertable query failed (%s)\n", mysql_error(&mysql));
	}
	else {
		printf("insert usertable query success\n");
	}


}

void RD::start() {

	flag = true;

	connect();
	mysql_query(&mysql, "drop table CheckInTable;");
	mysql_query(&mysql, "drop table TurnOnTable;");
	mysql_query(&mysql, "drop table eventTable;");
	mysql_query(&mysql, "drop table runTable");
	mysql_query(&mysql, "drop table userTable");
	create();

	err = select("101");

}

void RD::remove(string str) {

}

MYSQL_ROW RD::select(string str) {
//	lock_guard<std::mutex> lock(mMutex);
	string select = "select * from runTable where room_id=" + str + ";";
	MYSQL_RES* res = NULL; //����ṹ���������е�һ����ѯ�����
	//while (res == NULL) {
	//	select = "select * from runTable where room_id=" + str + ";";
	//	if (mysql_real_query(&mysql, select.c_str(), strlen(select.c_str()))) {
	//		printf("selcet query failed (%s)\n", mysql_error(&mysql));
	//	}
	//	else {
	//		printf("select query success\n");
	//	}
	//	res = mysql_store_result(&mysql);
	//}
	// 
	//select = "select * from runTable where room_id=" + str + ";";
	for (int i = 0;res == NULL && i<3; i++) {
		if (flag && mysql_real_query(&mysql, select.c_str(), strlen(select.c_str()))) {
			printf("selcet query failed (%s)\n", mysql_error(&mysql));
			//fprintf_s(f, "select query failed(%s)\n\n\n", mysql_error(&mysql));
			if (flag) {
				flag = false;
				freeConnect();
				connect();
				flag = true;
			}
		}
		else {
			printf("select query success\n");
		}
		res = mysql_store_result(&mysql);
	}

	if (res == NULL) {
		return err;
	}

	return mysql_fetch_row(res);
}
//MYSQL_RES* RD::selectF(int f) {
//	string select;
//	MYSQL_RES* res = NULL; //����ṹ���������е�һ����ѯ�����
//
//	while (res == NULL) {
//		select = "select * from runTable where room_id>" + to_string(f*100) + "and room_id<" + to_string((f+1)*100) + ";";
//		if (mysql_real_query(&mysql, select.c_str(), strlen(select.c_str()))) {
//			printf("selcet query failed (%s)\n", mysql_error(&mysql));
//		}
//		else {
//			printf("select query success\n");
//		}
//		res = mysql_store_result(&mysql);
//	}
//	//if (res == NULL) {
//	//	string temp = str;
//	//}
//
//	return res;
//}
void RD::Update(const Json::Value root) {
	string str;
	string event = root["event"].asString();
	if (event == "off") {//�ػ�ʱ����turnontable�Ĺػ�ʱ���뵱�η���
		str = "update runTable set running_time=";
		str += root["timestamp"].asString();
		//str += ",tot_fee=";
		//str += to_string(root["data"]["tot_fee"].asDouble());
		str += ",fee = 0";
		str += ",state = 0";
		str += " where room_id=";
		str += to_string(root["room_id"].asInt());
		str += ";";//-1
		//str += root["turnOn_time"].asString();
		//str += ";";
		if (mysql_query(&mysql, str.c_str())) {        //ִ��SQL���
			printf("Query failed (%s)\n", mysql_error(&mysql));
		}
		else {
			printf("update query success\n");
		}
	}
	if (event == "set") {//�ı����ʱ�����º�ķ��ٴ������ݿ���
		str = "update runTable set wind=";
		str += to_string(root["data"]["wind"].asInt());
		str += ",cur_temp=";
		str += to_string(root["data"]["cur_tem"].asDouble());
		str += ",tar_temp=";
		str += to_string(root["data"]["tar_tem"].asDouble());
		str += ",state=";
		str += to_string(root["data"]["state"].asInt());
		str += " where room_id=";
		str += to_string(root["room_id"].asInt());
		str += ";";
		if (mysql_query(&mysql, str.c_str())) {
			printf("Query failed (%s)\n", mysql_error(&mysql));
		}
		else {
			printf("update query success\n");
		}
	}
	else if (event == "tem") {//�յ��¶Ȱ������¶�Ӧ������¶����ݣ�״̬�����ϴ��յ�����ʱ�����Ϣ
		str = "update runTable set cur_temp=";
		str += to_string(root["data"]["cur_tem"].asDouble());
		str += ",running_time=";
		str += root["timestamp"].asString();
		str += ",tot_fee=";
		str += to_string(root["data"]["tot_fee"].asDouble());
		str += ",fee=";
		str += to_string(root["data"]["cur_fee"].asDouble());
		str += ",state=";
		str += to_string(root["data"]["state"].asInt());
		str += " where room_id=";
		str += to_string(root["room_id"].asInt());
		str += ";";
		if (mysql_query(&mysql, str.c_str())) {        //ִ��SQL���
			printf("event tem updata query failed (%s)\n", mysql_error(&mysql));
		}
		else {
			printf("event tem update query success\n");
		}
	}
	else if (event == "on") {
		str = "update runTable set running_time=";
		str += root["timestamp"].asString();
		str += ",cur_temp=";
		str += to_string(root["data"]["cur_tem"].asInt());
		str += ",tar_temp=";
		str += to_string(root["data"]["tar_tem"].asInt());
		str += ",wind=";
		str += to_string(root["data"]["wind"].asInt());
		str += ",state=";
		str += to_string(root["data"]["state"].asInt());
		str += " where room_id = ";
		str += to_string(root["room_id"].asInt());
		str += ";";
		if (mysql_query(&mysql, str.c_str())) {        //ִ��SQL���
			printf("event on updata query failed (%s)\n", mysql_error(&mysql));
		}
		else {
			printf("event on update query success\n");
		}
	}
	else if (event == "sch") {
		str = "update runTable set state=";
		str += to_string(root["data"]["state"].asInt());
		str += " where room_id=";
		str += to_string(root["room_id"].asInt());
		str += ";";
		if (mysql_query(&mysql, str.c_str())) {
			printf("Query failed (%s)\n", mysql_error(&mysql));
		}
		else {
			printf("update query success\n");
		}
	}
	//else if (event == "fee") {
	//	str = "update runTable set running_time=";
	//	str += root["timestamp"].asString();
	//	str += ",fee=";
	//	str += to_string(root["data"]["tot_fee"].asInt());
	//	str += ",state=";
	//	str += to_string(root["state"].asInt());
	//	str += " where room_id = ";
	//	str += to_string(root["room_id"].asInt());
	//	str += ";";
	//	if (mysql_query(&mysql, str.c_str())) {        //ִ��SQL���
	//		printf("event fee updata query failed (%s)\n", mysql_error(&mysql));
	//	}
	//	else {
	//		printf("event fee update query success\n");
	//	}
	//}
}

bool RD::InsertToRunTable(string room_id, string timestamp, string cur_temp, string tar_temp, string wind, string tot_fee,string fee, string mode, string type,string state) {
	//sql���
	string insert_runTable_sql;

	insert_runTable_sql += ("insert into runTable values (" + room_id + "," + timestamp + "," + cur_temp + "," + tar_temp + "," + wind + "," + tot_fee + "," + fee + "," + mode + "," + type + "," + state + ");");
	if (mysql_query(&mysql, insert_runTable_sql.c_str())) {
		cout << "Fail to insert to runTable: " << mysql_error(&mysql) << endl;
		return false;
	}
	else {
		cout << "Insert to runTable successfully!" << endl;
		return true;
	}
}
bool RD::InsertToEventTable(const Json::Value root) {
	string insert_TurnOnTable_sql;
	//������ʾ�ǿ���״̬ʱ
	string room_id = to_string(root["room_id"].asInt());
	string timestamp = root["timestamp"].asString();
	string event_type = to_string(root["event_type"].asInt());
	string fee = to_string(root["data"]["cur_fee"].asDouble());
	string wind = to_string(root["data"]["wind"].asInt());
	string wait_time = to_string(root["wait_time"].asInt());

	insert_TurnOnTable_sql += ("insert into eventTable values (" + room_id + "," + timestamp + "," + event_type + "," + fee +"," + wind + "," + wait_time + ");");

	if (mysql_query(&mysql, insert_TurnOnTable_sql.c_str())) {
		cout << "Fail to insert to eventTable: " << mysql_error(&mysql) << endl;
		return false;
	}
	else {
		cout << "Insert to eventTable successfully!" << endl;
		return true;
	}
}
