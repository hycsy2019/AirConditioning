#pragma once

#include <iostream>
#include <string>
#include <mysql.h>
#include <json/json.h>

#include <mutex>

#pragma comment(lib,"json_vc71_libmtd.lib")
#pragma comment(lib,"libmysql.lib")

using namespace std;

class RD
{
public:
	void start();//�������ݿ�
	bool connect();
	void freeConnect();
	void create();//�������ݿ�
//	MYSQL_ROW retRow() { return row; }

	void remove(string str);
	MYSQL_ROW select(string str);
	//MYSQL_RES* selectF(int f);

	//void Insert(const Json::Value root);
	void Update(const Json::Value root);
	bool InsertToRunTable(string room_id, string timestamp, string cur_temp, string tar_temp, string wind, string tot_fee, string fee, string mode, string type, string state);
	bool InsertToEventTable(const Json::Value root);
private:

	bool flag;

	MYSQL_ROW err;

	MYSQL mysql;

//	mutex mMutex;
	//MYSQL_RES* res; //����ṹ���������е�һ����ѯ�����
	//MYSQL_ROW row;
};

//{"room_id":104,"event":"on","timestamp":"202104011504","data":{"cur_temp":29,"tar_temp":26,"wind":0,"mode":0,}}