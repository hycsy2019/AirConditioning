#include "RoomInfo.h"


RoomInfo::RoomInfo(const Json::Value root) {
	room_id = root["room_id"].asInt();
	wind = root["data"]["wind"].asInt(); 
	cur_temp = root["data"]["cur_temp"].asInt();
	tar_temp = root["data"]["tar_temp"].asInt();
	mode = root["data"]["mode"].asInt();
	state = 1; 
	start_time = strtoll(root["timestamp"].asString().c_str(),NULL,10);
	last_time = strtoll(root["timestamp"].asString().c_str(), NULL, 10);
	total_fee = 0;

	//this->hdl = hdl;
}

//int RoomInfo::getfee(long long timestamp) {
//	int fee = long long(abs(cur_temp - tar_temp) * (2 * wind)) * (timestamp - last_time) / 100;
//	total_fee += fee;
//	return fee;
//}