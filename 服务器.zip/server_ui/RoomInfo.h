#pragma once

#include <websocketpp/config/asio_no_tls.hpp>
#include <websocketpp/server.hpp>
#include <json/json.h>
#include "DataBaseContor.h"


#pragma comment(lib,"json_vc71_libmtd.lib")

class RoomInfo
{
public:
	RoomInfo(const Json::Value root);
	int getRoomID() { return room_id; }
	int getWind() { return wind; }
	int getCurTemp() { return cur_temp; }
	int getTarTemp() { return tar_temp; }
	long long getTurnOnTime() { return start_time; }
	long long getLastTime() { return last_time; }
	int getState() { return state; }
	int getTotalFee() { return total_fee; }

	void changeWind(int wind) { this->wind = wind; }
	void changeCurTemp(int cur_temp) { this->cur_temp = cur_temp; }
	void changeTarTemp(int tar_temp) { this->tar_temp = tar_temp; }
	void changeLastTime(long long last_time) { this->last_time = last_time; }
	void changeState() { state = !state; }
//	int getfee(long long timestamp);
private:
	//websocketpp::connection_hdl hdl;
	int room_id;
	int wind;
	int cur_temp;
	int tar_temp;
	int total_fee;
	bool state;
	int mode;
	long long start_time;
	long long last_time;
};

