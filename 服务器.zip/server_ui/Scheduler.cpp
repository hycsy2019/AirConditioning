#include "Scheduler.h"

int MYSIZE = 3;

Scheduler::Scheduler() {
	//queue<Room> temp;
	//for (int i = 3; i > 0; i--) {
	//	runQueue.insert(pair<int,queue<Room>>(i,temp));
	//	waitQueue.insert(pair<int, queue<Room>>(i, temp));
	//}
}

bool Scheduler::notFull() {
	//int mySize = SIZE;
	//for (int i = 3; i > 0; i--) {
	//	mySize -= runQueue[i].size();
	//}
	//if (mySize > 0)return true;

	if (runQueue.size() < MYSIZE)return true;

	return false;
}



void Scheduler::dispatch(int room_id, int wind, vector<Room>& room){
	//Room temp;
	//bool flag = false;
	//int tempid;

	//temp.wind = wind;

	//for (int i = 3; i > 0; i--) {//��������е�Ŀ�귿��
	//	int runQueueSize = runQueue[i].size();
	//	for (int j = 0; j < runQueueSize; j++) {//�����ж�����Ѱ��Ŀ�귿��
	//		temp = runQueue[i].front();
	//		runQueue[i].pop();
	//		if (temp.room_id == room_id) {
	//			flag = true;
	//		}
	//		else {
	//			runQueue[i].push(temp);
	//		}
	//	}

	//	int waitQueueSize = waitQueue[i].size();
	//	for (int j = 0; j < waitQueueSize; j++) {//�ڵȴ�������Ѱ��Ŀ�귿��
	//		temp = waitQueue[i].front();
	//		waitQueue[i].pop();
	//		if (temp.room_id == room_id) {
	//			flag = true;
	//		}
	//		else {
	//			runQueue[i].push(temp);
	//		}
	//	}
	//	if (flag)break;
	//}

	//if (notFull()) {//���ж���δ��ʱ����ֱ�Ӽ�������
	//	temp.room_id = room_id;
	//	temp.waiting_time = 0;
	//	runQueue[wind].push(temp);
	//	return -1;
	//}

	//flag = false;
	//for (int i = 0; i <= wind ; i++) {//�ж��Ƿ������ȼ����͵ķ���ɵ�������
	//	if (!flag && i < wind && runQueue[i].size()) {//������ͣ���ȼ��͵ķ���
	//		flag = true;
	//		waitQueue[i].push(runQueue[i].front());
	//		tempid = runQueue[i].front().room_id;
	//		runQueue[i].pop();
	//	}
	//	if (i == wind) {//���ȿ���Ŀ�귿��յ�
	//		temp.room_id = room_id;
	//		temp.waiting_time = 0;
	//		if (flag) {
	//			runQueue[i].push(temp);
	//			return tempid;
	//		}
	//		waitQueue[i].push(temp);
	//	}
	//}

	//return room_id;

	Room temp;
	temp.room_id = room_id;
	temp.waiting_time = 0;
	temp.wind = wind;

	bool flag = false;
	for (int i = 0; i < runQueue.size(); i++) {//���ڷ���������޸ķ���
		if (runQueue[i].room_id == room_id) {
			runQueue[i].wind = wind;
			temp.waiting_time = 1;
			room.push_back(temp);

			if (wind == 0) {
				runQueue.erase(runQueue.begin() + i);
				if (waitQueue.size() > 0) {
					room.push_back(waitQueue[0]);
					waitQueue[0].waiting_time = 0;
					waitQueue.erase(waitQueue.begin());
				}
				else {
					room[0].waiting_time = 0;
				}
			}

			return;
		}
	}
	for (int i = 0; i < waitQueue.size(); i++) {//�ڵȴ��������޸ķ���
		if (waitQueue[i].room_id == room_id) {
			waitQueue[i].wind = wind;

			if (wind == 0) {
				temp.waiting_time = waitQueue[i].waiting_time;
				room.push_back(temp);
				waitQueue.erase(waitQueue.begin() + i);
			}

			return;
		}
		if (i > 1000) {
			int err = 0;
		}
	}

	if (wind == 0) {
		temp.waiting_time = 1;
		room.push_back(temp);
		return;
	}

	if (notFull()) {//�������δ��ֱ�Ӽ���������
		runQueue.push_back(temp);
		temp.waiting_time = 1;
		room.push_back(temp);
		return;
	}
	else {
		int key = -1,tempwind = wind;
		for (int i = 0; i < runQueue.size(); i++) {
			if (tempwind > runQueue[i].wind) {
				key = i;
				tempwind = runQueue[i].wind;
			}
		}
		if (key > -1) {
			runQueue[key].waiting_time = 0;
			waitQueue.push_back(runQueue[key]);
			room.push_back(runQueue[key]);
			runQueue.erase(runQueue.begin()+key);
			runQueue.push_back(temp);
			temp.waiting_time = 1;
			room.push_back(temp);
		}
		else {
			waitQueue.push_back(temp);
		}
		return;
	}

}

void Scheduler::scheduling(vector<Room>& room) {
	int mySize = MYSIZE;
	Room temp;

	//if (notFull()) return;
	//for (int i = 3; i > 0; i--) {
	//	if (mySize == runQueue[i].size()) {

	//		int waitQueueSize = waitQueue[i].size();
	//		for (int j = 0; j < min(waitQueueSize,mySize); j++) {//ʱ��Ƭ����
	//			temp = waitQueue[i].front();
	//			waitQueue[i].pop();
	//			room.push_back(temp);
	//			temp.waiting_time = 0;
	//			runQueue[i].push(temp);
	//			waitQueue[i].push(runQueue[i].front());
	//			room.push_back(runQueue[i].front());
	//			runQueue[i].pop();
	//		}
	//		for (int j = 0; j < waitQueue[i].size();j++) {//���ӵȴ������еȴ�ʱ��
	//			temp = waitQueue[i].front();
	//			waitQueue[i].pop();
	//			temp.waiting_time += 10000;
	//			waitQueue[i].push(temp);
	//		}
	//	}
	//	mySize -= runQueue[i].size();
	//}
	for (int i = 0; i < runQueue.size(); i++) {//���ӷ���ʱ��
		runQueue[i].waiting_time += 3;
	}
	for (int i = 0; i < waitQueue.size(); i++) {//���ӵȴ�ʱ��
		waitQueue[i].waiting_time += 3;
	}
	for (int i = 0; i < waitQueue.size(); i++) {//�жϵȴ�ʱ���Ƿ񳬹�2����
		if (waitQueue[i].waiting_time >= 120) {
			room.push_back(waitQueue[i]);//����������з���
		}
	}
	int roomSize = room.size();
	for (int i = 0; i < roomSize; i++) {//��Ϊ�ȴ����������һ�����䣬����дûʲô��ϵ������͵���˵�
		runQueue[0].waiting_time = 0;
		room.push_back(runQueue[0]);
		waitQueue.push_back(runQueue[0]);
		runQueue.erase(runQueue.begin());
		runQueue.push_back(room[i]);
		waitQueue.erase(waitQueue.begin());
	}
}