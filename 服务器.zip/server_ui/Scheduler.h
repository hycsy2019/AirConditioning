#pragma once

#include<map>
#include<queue>
#include<string>
#include<Windows.h>

using namespace std;

struct Room
{
	int room_id;
	int waiting_time;
	int wind;
};



class Scheduler
{
public:
	//bool isRunning(int room_id);
	Scheduler();
	bool notFull();

	void dispatch(int room_id, int wind, vector<Room>& room);
	//int dispatch(int room_id, int wind);
	void scheduling(vector<Room>& room);

private:
	//map<int,queue<Room>> runQueue;
	//map<int,queue<Room>> waitQueue;

	vector<Room> runQueue;
	vector<Room> waitQueue;
};

