#include "server_ui.h"
#include <QtWidgets/QApplication>
#include <QtCore/QTextCodec>  

#include <thread>

FILE *p = fopen("C:\\Users\\dq2000\\Desktop\\server_ui\\Debug\\config.txt", "r");

//FILE* p = fopen("config.txt", "r");

extern int TEM_LOW_LIMIT;
extern int TEM_HIGH_LIMIT;

int startUI(int argc, char* argv[], RD* DataBase) {
    QApplication a(argc, argv);

    server_ui w(DataBase);
    w.show();
    return a.exec();

 //   printf("???\n");
}

void startServer(RD* DataBase) {
    Monitor myServer(DataBase);


    thread t(bind(&Monitor::re_message, &myServer));

    myServer.run();
}


int main(int argc, char *argv[])
{
    fscanf_s(p, "%d %d", &TEM_LOW_LIMIT, &TEM_HIGH_LIMIT);

    RD DataBase;
    //Scheduler queue;
    DataBase.start();
    
    thread server(startServer, &DataBase);
//    thread ui(startUI, argc, argv, &DataBase);

    startUI(argc, argv, &DataBase);

 //   printf("???\n");

    return 0;
}
