#include "server_ui.h"
#include <QTimer>
#include <QDateTime>
#include <QString>
#include <Qmessagebox>


QTimer* timer;


server_ui::server_ui(RD* DataBase,QWidget *parent): QMainWindow(parent)
{
	key_floor = 0;
	this->DataBase = DataBase;

    ui.setupUi(this);
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(qtimeSlot()));
    timer->start(1000);

	ui.doubleSpinBox->setValue(PRICE);
	ui.doubleSpinBox->setSuffix("��");

	timer_updata = new QTimer(this);
	connect(timer_updata, SIGNAL(timeout()), this, SLOT(updata_floor()));
	timer_updata->start(5000);
	//connect(ui.pB_power, SIGNAL(clicked()), this, SLOT(set_power_on));
	//connect(ui.cB_mode, SIGNAL(currentIndexChanged(int)), this, SLOT(set_mode));
	//connect(ui.pB_floor1, SIGNAL(clicked()), this, SLOT(click_pB_floor1));
	//connect(ui.pB_floor2, SIGNAL(clicked()), this, SLOT(click_pB_floor2));
	//connect(ui.pB_floor3, SIGNAL(clicked()), this, SLOT(click_pB_floor3));
	//connect(ui.pB_floor4, SIGNAL(clicked()), this, SLOT(click_pB_floor4));

}

void server_ui::qtimeSlot()
{
	QTime qtimeObj = QTime::currentTime();
	QString strTime = qtimeObj.toString("ap h:mm");
	strTime.prepend("   ");
	QDate qdateObj = QDate::currentDate();
	QString strDate = qdateObj.toString("yyyy.M.d"); 

	strDate.append(strTime);
	QString lowlimit = "���ޣ�" + QString::number(TEM_LOW_LIMIT);
	QString highlimit = "���ޣ�" + QString::number(TEM_HIGH_LIMIT);

	strDate.append(lowlimit);
	strDate.append(highlimit);
	ui.timeLabel->setText(strDate);

}

//ͨ��¥���������������������,���ֱ�Ӵ�ӡ
void server_ui::show_floor_info(int floor)
{
	string cur_room_id;

	//MYSQL_RES* res = DataBase->selectF(floor);

	for (int i = 1; i <= 10; i++) {

		cur_room_id = to_string(floor * 100 + i);

		MYSQL_ROW row = DataBase->select(cur_room_id);	//��ѯ��ǰ������Ϣ
		//MYSQL_ROW row = mysql_fetch_row(res);
//		QString::fromStdString(str);
		switch (i) {
		case 1: 
			ui.textEdit_room1->clear();
			ui.textEdit_room1->append(QString::fromStdString("�����:" + cur_room_id + "\n"
				+ "���٣�" + row[4] + "    "
				+ "ģʽ��" + row[7] + "\n"
				+ "��ǰ�¶ȣ�" + row[2] + "\n"
				+ "Ŀ���¶ȣ�" + row[3] + "\n"
				+ "���η��ã�" + row[6] + "\n"
				+ "�ܷ��ã�" + row[5] + "\n"
				+ "״̬��" + STATE[atoi(row[9]) + 1]));
			break;
		case 2:
			ui.textEdit_room2->clear();
			ui.textEdit_room2->append(QString::fromStdString("�����:" + cur_room_id + "\n"
				+ "���٣�" + row[4] + "    "
				+ "ģʽ��" + row[7] + "\n"
				+ "��ǰ�¶ȣ�" + row[2] + "\n"
				+ "Ŀ���¶ȣ�" + row[3] + "\n"
				+ "���η��ã�" + row[6] + "\n"
				+ "�ܷ��ã�" + row[5] + "\n"
				+ "״̬��" + STATE[atoi(row[9]) + 1]));
			break;
		case 3:
			ui.textEdit_room3->clear();
			ui.textEdit_room3->append(QString::fromStdString("�����:" + cur_room_id + "\n"
				+ "���٣�" + row[4] + "    "
				+ "ģʽ��" + row[7] + "\n"
				+ "��ǰ�¶ȣ�" + row[2] + "\n"
				+ "Ŀ���¶ȣ�" + row[3] + "\n"
				+ "���η��ã�" + row[6] + "\n"
				+ "�ܷ��ã�" + row[5] + "\n"
				+ "״̬��" + STATE[atoi(row[9]) + 1]));
			break;
		case 4:
			ui.textEdit_room4->clear();
			ui.textEdit_room4->append(QString::fromStdString("�����:" + cur_room_id + "\n"
				+ "���٣�" + row[4] + "    "
				+ "ģʽ��" + row[7] + "\n"
				+ "��ǰ�¶ȣ�" + row[2] + "\n"
				+ "Ŀ���¶ȣ�" + row[3] + "\n"
				+ "���η��ã�" + row[6] + "\n"
				+ "�ܷ��ã�" + row[5] + "\n"
				+ "״̬��" + STATE[atoi(row[9]) + 1]));
			break;
		case 5:
			ui.textEdit_room5->clear();
			ui.textEdit_room5->append(QString::fromStdString("�����:" + cur_room_id + "\n"
				+ "���٣�" + row[4] + "    "
				+ "ģʽ��" + row[7] + "\n"
				+ "��ǰ�¶ȣ�" + row[2] + "\n"
				+ "Ŀ���¶ȣ�" + row[3] + "\n"
				+ "���η��ã�" + row[6] + "\n"
				+ "�ܷ��ã�" + row[5] + "\n"
				+ "״̬��" + STATE[atoi(row[9]) + 1]));
			break;
		case 6:
			ui.textEdit_room6->clear();
			ui.textEdit_room6->append(QString::fromStdString("�����:" + cur_room_id + "\n"
				+ "���٣�" + row[4] + "    "
				+ "ģʽ��" + row[7] + "\n"
				+ "��ǰ�¶ȣ�" + row[2] + "\n"
				+ "Ŀ���¶ȣ�" + row[3] + "\n"
				+ "���η��ã�" + row[6] + "\n"
				+ "�ܷ��ã�" + row[5] + "\n"
				+ "״̬��" + STATE[atoi(row[9]) + 1]));
			break;
		case 7:
			ui.textEdit_room7->clear();
			ui.textEdit_room7->append(QString::fromStdString("�����:" + cur_room_id + "\n"
				+ "���٣�" + row[4] + "    "
				+ "ģʽ��" + row[7] + "\n"
				+ "��ǰ�¶ȣ�" + row[2] + "\n"
				+ "Ŀ���¶ȣ�" + row[3] + "\n"
				+ "���η��ã�" + row[6] + "\n"
				+ "�ܷ��ã�" + row[5] + "\n"
				+ "״̬��" + STATE[atoi(row[9]) + 1]));
			break;
		case 8:
			ui.textEdit_room8->clear();
			ui.textEdit_room8->append(QString::fromStdString("�����:" + cur_room_id + "\n"
				+ "���٣�" + row[4] + "    "
				+ "ģʽ��" + row[7] + "\n"
				+ "��ǰ�¶ȣ�" + row[2] + "\n"
				+ "Ŀ���¶ȣ�" + row[3] + "\n"
				+ "���η��ã�" + row[6] + "\n"
				+ "�ܷ��ã�" + row[5] + "\n"
				+ "״̬��" + STATE[atoi(row[9]) + 1]));
			break;
		case 9:
			ui.textEdit_room9->clear();
			ui.textEdit_room9->append(QString::fromStdString("�����:" + cur_room_id + "\n"
				+ "���٣�" + row[4] + "    "
				+ "ģʽ��" + row[7] + "\n"
				+ "��ǰ�¶ȣ�" + row[2] + "\n"
				+ "Ŀ���¶ȣ�" + row[3] + "\n"
				+ "���η��ã�" + row[6] + "\n"
				+ "�ܷ��ã�" + row[5] + "\n"
				+ "״̬��" + STATE[atoi(row[9]) + 1]));
			break;
		case 10:
			ui.textEdit_room10->clear();
			ui.textEdit_room10->append(QString::fromStdString("�����:" + cur_room_id + "\n"
				+ "���٣�" + row[4] + "    "
				+ "ģʽ��" + row[7] + "\n"
				+ "��ǰ�¶ȣ�" + row[2] + "\n"
				+ "Ŀ���¶ȣ�" + row[3] + "\n"
				+ "���η��ã�" + row[6] + "\n"
				+ "�ܷ��ã�" + row[5] + "\n"
				+ "״̬��" + STATE[atoi(row[9]) + 1]));
			break;
		default:
			break;
			
		}
	}
}

//void server_ui::set_price()
//{
//	if (!this->power_on) {
//		//�ػ�
//		ui.doubleSpinBox->setReadOnly(false);
//		//this->price = ui.doubleSpinBox->value();
//		PRICE = ui.doubleSpinBox->value();
//		
//	}
//	else {
//		//����
//		ui.doubleSpinBox->setReadOnly(true);
//	
//	}
//}
void server_ui::set_price()
{
	if (!this->power_on) {
		//�ػ�
		PRICE = ui.doubleSpinBox->value();
//		this->pre_price = PRICE;
	}
	else {
		//����
		ui.doubleSpinBox->setValue(PRICE);
		QMessageBox::warning(this, "ϵͳ��ʾ", "����״̬�����趨");
	}
}

//void server_ui::set_mode()
//{
//	if (!this->power_on) {
//		//�ػ�
//		QVariant v(0);
//		ui.cB_mode->setItemData(0, QVariant(32), Qt::UserRole - 1);
//		ui.cB_mode->setItemData(1, QVariant(32), Qt::UserRole - 1);
//		
//		int cur_mode = ui.cB_mode->currentIndex();
//		//this->mode = cur_mdoe;
//		MODE = cur_mode;
//	}
//	else {
//		//����
//		ui.cB_mode->setItemData(0, QVariant(0), Qt::UserRole - 1);
//		ui.cB_mode->setItemData(1, QVariant(0), Qt::UserRole - 1);
//		//ui.cB_mode->setCurrentIndex(this->mode);
//		ui.cB_mode->setCurrentIndex(MODE);
//		QMessageBox::warning(this, "ϵͳ��ʾ", "����״̬�����趨");
//	}
//}
void server_ui::set_mode()
{
	if (!this->power_on) {
		//�ػ�
		int cur_mdoe = ui.cB_mode->currentIndex();
		MODE = cur_mdoe;
	}
	else {
		//����
		ui.cB_mode->setCurrentIndex(MODE);
		QMessageBox::warning(this, "ϵͳ��ʾ", "����״̬�����趨");
	}
}

//void server_ui::set_power_on()
//{
//	this->power_on = this->power_on ^ 1;//�ı䵱ǰ����״̬
//}
void server_ui::set_power_on()
{
	this->power_on = this->power_on ^ 1;//�ı䵱ǰ����״̬
	if (this->power_on) {
		ui.pB_power->setStyleSheet("border-image: url(:/server_ui/open1.png)");
	}
	else {
		ui.pB_power->setStyleSheet("border-image: url(:/server_ui/close1.png)");
	}
}

void server_ui::click_pB_floor1()
{
	if (this->power_on) {
		key_floor = 1;
		ui.pB_floor1->setStyleSheet("color:white,background-color: rgba(0,255,0,100)");
		show_floor_info(1);
			
		
	}
}

void server_ui::click_pB_floor2()
{
	if (this->power_on) {
		key_floor = 2;

		ui.pB_floor2->setStyleSheet("color:red,background-color: rgba(0,255,0,100)");
		show_floor_info(2);
		ui.pB_floor2->setText("��¥");
	}
	else {
		ui.pB_floor2->setText("nopower");
	}
	
}

void server_ui::click_pB_floor3()
{
	if (this->power_on) {
		key_floor = 3;
		ui.pB_floor3->setStyleSheet("color:red,background-color: rgba(0,255,0,100)");
		show_floor_info(3);
	}
	
}

void server_ui::click_pB_floor4()
{
	if (this->power_on) {
		key_floor = 4;
		ui.pB_floor4->setStyleSheet("color:red,background-color: rgba(0,255,0,100)");
		show_floor_info(4);
	}
	
}

void server_ui::updata_floor() {
	switch (key_floor) {
	case 1:
		click_pB_floor1();
		break;
	case 2:
		click_pB_floor2();
		break;
	case 3:
		click_pB_floor3();
		break;
	case 4:
		click_pB_floor4();
		break;
	default:
		break;
	}
}