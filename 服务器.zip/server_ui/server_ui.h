#pragma once
#pragma execution_character_set("utf-8")

#include <QtWidgets/QMainWindow>
#include "ui_server_ui.h"
//#include"RD.h"
#include "CenterServer.h"

using namespace std;

extern int PRICE;
extern int MODE;
extern string STATE[];

extern int TEM_LOW_LIMIT;
extern int TEM_HIGH_LIMIT;
extern int DEFAULT_TAR_TEM;

class server_ui : public QMainWindow
{
    Q_OBJECT

public:
    server_ui(RD* DataBase,QWidget *parent = Q_NULLPTR);
    
    void show_floor_info(int floor);

private:
    Ui::server_uiClass ui;
    bool power_on = false;  //��Դ����
//    double pre_price = 10.00;
    double price = 10.00;   //����
    int mode = 0;           //0:����,1:����
    int key_floor;

    QTimer* timer_updata;

    //Scheduler* queue;

    RD* DataBase;

private slots:
    void qtimeSlot();
    void click_pB_floor1();
    void click_pB_floor2();
    void click_pB_floor3();
    void click_pB_floor4();

    void updata_floor();

    void set_price();       //�޸ķ���
    void set_mode();        //�޸�ģʽ
    void set_power_on();    //��Դ����
};
